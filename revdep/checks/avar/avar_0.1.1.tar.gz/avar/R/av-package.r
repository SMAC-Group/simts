#' @keywords internal
#' @importFrom Rcpp evalCpp
#' @importFrom grDevices hcl
#' @useDynLib avar
#' @import graphics simts
#' @name avar
#' @docType package
#' @exportPattern ^[[:alpha:]]+
NULL
