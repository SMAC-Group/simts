#ifndef SP_DWT
#define SP_DWT

arma::field<arma::vec> sp_modwt_cpp(const arma::mat& X, 
                                    int J1, int J2);

#endif
