#' wv
#' @keywords internal
#' @importFrom Rcpp evalCpp
#' @importFrom grDevices hcl 
#' @useDynLib wv
#' @import graphics
#' @name wv
#' @docType package
NULL
