#ifndef SPATIAL_FILTER_H
#define SPATIAL_FILTER_H

arma::vec sp_hfilter(int jscale);

#endif
